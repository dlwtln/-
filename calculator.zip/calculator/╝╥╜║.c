#include <stdio.h>
#include <string.h>
#define MAX 256
void main()
{
	int count, len1, len2, i, j = 0;
	char *ptr1, *ptr2, op;
	char str[MAX * 2 + 1], num1[MAX + 1], num2[MAX + 1], sum[MAX + 2];
	scanf("%s", str);
	for (i = 0; i < strlen(str); i++)
	{
		num1[i] = str[i];
		if (str[i] == '+' || str[i] == '-')
			break;
	}
	num1[i] = '\0';
	op = str[i++];
	for (; i < strlen(str); i++)
	{
		num2[j++] = str[i];
	}
	num2[j] = '\0';
	if (op == '+')
	{
		if (strlen(num1) < strlen(num2)) { ptr1 = num2; ptr2 = num1; }
		else { ptr1 = num1; ptr2 = num2; }
		len1 = strlen(ptr1); len2 = strlen(ptr2);
		sum[0] = '0'; sum[len1 + 1] = 0x00;
		for (count = 0; count < len2; count++)
			sum[len1 - count] = ptr1[len1 - count - 1] + (ptr2[len2 - count - 1] - '0');
		for (; count < len1; count++) sum[len1 - count] = ptr1[len1 - count - 1];
		for (count = len1; count > 0; count--)
			if (sum[count] > '9') { sum[count - 1]++; sum[count] -= 10; }
		printf("%s + %s = %s\n", num1, num2, (sum[0] == '0') ? &sum[1] : &sum[0]);
	}
	if (op == '-')
	{
		if (strlen(num1) < strlen(num2)) { ptr1 = num2; ptr2 = num1; }
		else { ptr1 = num1; ptr2 = num2; }
		len1 = strlen(ptr1); len2 = strlen(ptr2);
		sum[0] = '0'; sum[len1 + 1] = 0x00;
		for (count = 0; count < len2; count++)
			sum[len1 - count] = ptr1[len1 - count - 1] - (ptr2[len2 - count - 1] - '0');
		for (; count < len1; count++) sum[len1 - count] = ptr1[len1 - count - 1];
		for (count = len1; count > 0; count--)
			if (sum[count] < '0') { sum[count - 1]--; sum[count] += 10; }
		if (sum[0] < '0') sum[0] = '-';
		printf("%s - %s = %s\n", num1, num2, (sum[0] == '0') ? &sum[1] : &sum[0]);
	}
}